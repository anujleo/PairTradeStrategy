-------Pair trade strategy read me-------

1. This project is solely for educational purposes

2. All techniques used my me is solely based on my understanding. There might be some limitation. If you find any correction mail at anuj.singh889401@gmail.com

3. Before accessing the codes its highly suggested to cover following chapters

a. Basics of Finance, Share market, Stock exchange, Future & Options, Intraday.
b. Basics of Pair trading strategy
c. PCA
d. Unsupervised learning with Machine learning on python
e. Basics of statistics

4. To understand why PCA and reference of my learning and strategy implementation i have attached study materials for reference. 

a. Why_PCA.pdf
b. PairsTradungGGR.pdf
c. Amy_Zhang.pdf




Thanks---
Anuj